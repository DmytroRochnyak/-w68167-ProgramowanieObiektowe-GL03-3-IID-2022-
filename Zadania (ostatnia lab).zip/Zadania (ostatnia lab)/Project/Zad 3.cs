﻿using System;
using System.Collections.Generic;

abstract class Kształt
{
    public abstract double X { get; set; }
    public abstract double Y { get; set; }

    public abstract double Obwód();
    public abstract double Pole();
}

class Prostokąt : Kształt
{
    public override double X { get; set; }
    public override double Y { get; set; }

    public Prostokąt(double x, double y)
    {
        X = x;
        Y = y;
    }

    public override double Obwód()
    {
        return 2 * (X + Y);
    }

    public override double Pole()
    {
        return X * Y;
    }
}

class Trójkąt : Kształt
{
    public override double X { get; set; }
    public override double Y { get; set; }

    public Trójkąt(double x, double y)
    {
        X = x;
        Y = y;
    }

    public override double Obwód()
    {
        return X + Y + Math.Sqrt(X * X + Y * Y); // Twierdzenie Pitagorasa
    }

    public override double Pole()
    {
        return 0.5 * X * Y;
    }
}

class Koło : Kształt
{
    public override double X { get; set; }
    public override double Y { get; set; }

    public Koło(double r)
    {
        X = r; // Promień
        Y = 0; // Drugi wymiar jest zbędny dla koła
    }

    public override double Obwód()
    {
        return 2 * Math.PI * X;
    }

    public override double Pole()
    {
        return Math.PI * X * X;
    }
}

class Program
{
    static void Main()
    {
        List<Kształt> listaKształtów = new List<Kształt>();

        listaKształtów.Add(new Prostokąt(3, 4));
        listaKształtów.Add(new Trójkąt(5, 12));
        listaKształtów.Add(new Koło(2));
        listaKształtów.Add(new Prostokąt(2, 6));

        Console.WriteLine("Kształty posiadające obwód większy od 10:");

        foreach (var kształt in listaKształtów)
        {
            if (kształt.Obwód() > 10)
            {
                Console.WriteLine($"Obwód: {kształt.Obwód()}, Pole: {kształt.Pole()}");
            }
        }

        Console.ReadKey();
    }
}
