﻿//using System;

//class Książka
//{
//    // Pola klasy Książka
//    public string Tytuł { get; set; }
//    public string Autor { get; set; }
//    public int RokWydania { get; set; }

//    // Konstruktor klasy Książka
//    public Książka(string tytuł, string autor, int rokWydania)
//    {
//        Tytuł = tytuł;
//        Autor = autor;
//        RokWydania = rokWydania;
//    }

//    // Metoda do wyświetlania informacji o książce
//    public void WyświetlInformacje()
//    {
//        Console.WriteLine($"Tytuł: {Tytuł}");
//        Console.WriteLine($"Autor: {Autor}");
//        Console.WriteLine($"Rok Wydania: {RokWydania}");
//        Console.WriteLine();
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        // Tworzenie obiektów klasy Książka
//        Książka książka1 = new Książka("Wiedźmin", "Andrzej Sapkowski", 1993);
//        Książka książka2 = new Książka("Harry Potter i Kamień Filozoficzny", "J.K. Rowling", 1997);
//        Książka książka3 = new Książka("1984", "George Orwell", 1949);

//        // Wywołanie metody do wyświetlania informacji o każdej książce
//        książka1.WyświetlInformacje();
//        książka2.WyświetlInformacje();
//        książka3.WyświetlInformacje();

//        Console.ReadKey();
//    }
//}

